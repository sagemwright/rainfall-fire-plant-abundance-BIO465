I. Rainfall Data Files
----------------------

1) All rain complete_R.csv

Monthly rainfall measurements (mm) from May 1995 - Sep 2012 for Main Camp, Field River, Carlo Shitty, and South Site. Data were collected daily via automated weather stations. If weather stations were not functioning for the entire month, then the monthly entry was left blank. 


2) Cumulative rain_R.csv

Multivariate Auto-regressive State-space models were created in R Statistical Software using the MARSS package. The best fitting model suggests a single state is sufficient to describe the rainfall trajectory for all four sites. The state estimates for this model was used to calculate 3 month cumulative rainfall to be used as a covariate for the Trachymene glaucifolia models. Dates and time series length were adjusted to match the population data. 

For more info on MARSS models see:
Holmes EE, Ward EJ, Scheuerell MD (2012) Analysis of multivariate time-series using the MARSS package. Version 3.4. http://cran.r-project.org/web/packages/MARSS.
Holmes EE, Ward EJ, Wills K (2012) MARSS: multivariate autoregressive state-space models for analyzing time series data. R Journal 4: 11-19.


II. Abundance estimates
-----------------------

1) Plot_XX_R.csv

Gives the raw abundance counts for the above ground plants of Trachymene glaucifolia for site "XX". In each site, counts were obtained in a burnt and unburnt grid (relative to the 2001-2002 Simpson Desert wildfire) with each grid consisting of 15 5x5 meter plots. File is formatted to be read into R Statistical Software.

Sites:
Plot_CS_R = Carlo Shitty
Plot_FR_R = Field River
Plot_MC_R = Main Camp
Plot_CS_R = South Site

Column headers:
Date		Gives the month and year of census count
Time		Gives the time step of census count
XX_B_Plot N	Gives the abundance count of above ground plants for site "XX", burnt grid, plot "N" 
XX_U_Plot N	Gives the abundance count of above ground plants for site "XX", unburnt grid, plot "N"


2) PlotSB_XX_R.csv

Gives the adjusted abundance counts for the seeds of Trachymene glaucifolia for site "XX". Soil samples were taken adjacent to each plot using a tray 2 cm deep covering a 20 � 20 cm area. Seeds within the samples were later sieved, identified and counted to estimate the size of the seed bank within each plot. Seed counts presented in the datasheet have been multiplied by 625 to adjust for the total size of the plot. File is formatted to be read into R Statistical Software.

Sites XX:
PlotSB_CS_R.csv = Carlo Shitty
PlotSB_FR_R.csv = Field River
PlotSB_MC_R.csv = Main Camp
PlotSB_SS_R.csv = South Site

Column headers:
Date		Gives the month and year of census count
Time		Gives the time step of census count
XX_B_SB_Plot N	Gives the adjusted abundance count (x625) of seeds for site "XX", burnt grid, plot "N"
XX_U_SB_Plot N	Gives the adjusted abundance count (x625) of seeds for site "XX", unburnt grid, plot "N"